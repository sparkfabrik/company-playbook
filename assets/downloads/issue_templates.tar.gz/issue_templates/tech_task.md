## Description and goal

_**Tip**: Explain your motivations and goals so that whoever takes it in charge can think of possible alternative solutions, if necessary._

## Tasks and activities

* [ ] Task 1
* [ ] Task 2
* ...

## Acceptance criteria

* [ ] The system has...
* [ ] We have a tool for...
* [ ] Data is successfully migrated...

/label ~Task
